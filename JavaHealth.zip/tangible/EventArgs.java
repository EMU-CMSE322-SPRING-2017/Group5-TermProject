package tangible;

public class EventArgs
{
	public static EventArgs Empty;

	public EventArgs()
	{
	}
}