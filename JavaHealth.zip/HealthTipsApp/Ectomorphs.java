package HealthTipsApp;

public class Ectomorphs extends Form
{
	public Ectomorphs()
	{
		InitializeComponent();
	}

	private void button1_Click(Object sender, tangible.EventArgs e)
	{
		Form1 main = new Form1();
		main.Show();
		this.Hide();
	}
	private void Ectomorphs_Load(Object sender, tangible.EventArgs e)
	{
		pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
		pictureBox1.ImageLocation = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzXVCS4y9qXDpdlaMeNWDxwaPsHhCmzieZLAuOvCgPrNcb8pCJzw";
		richTextBox1.Text = "The guy that inhales doughnuts and doesn’t gain an ounce.\n Ectomorphs are your chronically skinny guys – they tend to have a slight frame and have very quick metabolism.\n In general, they have a tough time gaining any sort of mass, whether it’s muscle or fat.\nNutrition Rules for Ectomorphs.\nIf you’re looking to gain mass and size, you don’t have to focus on cardiovascular work, typically.\nIf packing on weight is a priority, make sure you’re focusing on increasing and improving your strength training while also keeping nutrition in mind.\nAs an ectomorph, if you’re not conscious about what you’re putting in your body, you may gain little to no weight at all, regardless of whether it’s muscle or fat (and you want some of both).\nProtein and nutrition are important for guys of every body type, but ectomorphs need to be getting quality nutrients and calories in “every three hours.” \nDuring workout, you should concentrate on your legs.\nIt’s kind of the most surefire way of optimizing strength, through your legs.\nHone in on the large muscle groups like the glutes and quads to help you go about gaining size.";
	}


	/** 
	 Required designer variable.
	*/
	private System.ComponentModel.IContainer components = null;

	/** 
	 Clean up any resources being used.
	 
	 @param disposing true if managed resources should be disposed; otherwise, false.
	*/
	@Override
	protected void Dispose(boolean disposing)
	{
		if (disposing && (components != null))
		{
			components.Dispose();
		}
		super.Dispose(disposing);
	}

//C# TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
		///#region Windows Form Designer generated code

	/** 
	 Required method for Designer support - do not modify
	 the contents of this method with the code editor.
	*/
	private void InitializeComponent()
	{
		this.button1 = new System.Windows.Forms.Button();
		this.richTextBox1 = new System.Windows.Forms.RichTextBox();
		this.pictureBox1 = new System.Windows.Forms.PictureBox();
		((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
		this.SuspendLayout();
		// 
		// button1
		// 
		this.button1.Location = new System.Drawing.Point(147, 297);
		this.button1.Name = "button1";
		this.button1.Size = new System.Drawing.Size(75, 23);
		this.button1.TabIndex = 0;
		this.button1.Text = "Back";
		this.button1.UseVisualStyleBackColor = true;
//C# TO JAVA CONVERTER TODO TASK: Java has no equivalent to C#-style event wireups:
		this.button1.Click += new System.EventHandler(this.button1_Click);
		// 
		// richTextBox1
		// 
		this.richTextBox1.Location = new System.Drawing.Point(12, 97);
		this.richTextBox1.Name = "richTextBox1";
		this.richTextBox1.Size = new System.Drawing.Size(210, 194);
		this.richTextBox1.TabIndex = 1;
		this.richTextBox1.Text = "";
		// 
		// pictureBox1
		// 
		this.pictureBox1.Location = new System.Drawing.Point(54, 12);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new System.Drawing.Size(78, 79);
		this.pictureBox1.TabIndex = 2;
		this.pictureBox1.TabStop = false;
		// 
		// Ectomorphs
		// 
		this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.ClientSize = new System.Drawing.Size(234, 332);
		this.Controls.Add(this.pictureBox1);
		this.Controls.Add(this.richTextBox1);
		this.Controls.Add(this.button1);
		this.Name = "Ectomorphs";
		this.Text = "Ectomorphs";
//C# TO JAVA CONVERTER TODO TASK: Java has no equivalent to C#-style event wireups:
		this.Load += new System.EventHandler(this.Ectomorphs_Load);
		((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
		this.ResumeLayout(false);

	}

//C# TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
		///#endregion

	private System.Windows.Forms.Button button1;
	private System.Windows.Forms.RichTextBox richTextBox1;
	private System.Windows.Forms.PictureBox pictureBox1;
}