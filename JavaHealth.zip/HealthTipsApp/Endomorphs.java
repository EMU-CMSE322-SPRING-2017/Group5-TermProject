package HealthTipsApp;

public class Endomorphs extends Form
{
	public Endomorphs()
	{
		InitializeComponent();
	}

	private void button1_Click(Object sender, tangible.EventArgs e)
	{
		Form1 main = new Form1();
		main.Show();
		this.Hide();
	}

	private void Endomorphs_Load(Object sender, tangible.EventArgs e)
	{
		pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
		pictureBox1.ImageLocation = "http://moskovskaya-medicina.ru/sites/default/files/note5603.jpg";
		richTextBox1.Text = "The guy that looks at a doughnut and gains weight.\nEndomorphs are often short, stocky guys who gain muscle well but also pack on fat effortlessly. \nThey’re strong but also tend to carry around a lot of excess weight.\nDurkin points to good diet as the most important concern for endomorphs, followed closely by cardiovascular exercise. \nOf course, clean diet and running aren’t usually the easiest things for these guys to master, so it takes plenty of willpower. \nIf you’re an endomorph, don’t abandon your lifting and strength training, just consider scaling back if you want to shed some fat. \nA good, solid three days a week of strength training must be supplemented with at least three to four days of aerobic training as well.";
	}


	/** 
	 Required designer variable.
	*/
	private System.ComponentModel.IContainer components = null;

	/** 
	 Clean up any resources being used.
	 
	 @param disposing true if managed resources should be disposed; otherwise, false.
	*/
	@Override
	protected void Dispose(boolean disposing)
	{
		if (disposing && (components != null))
		{
			components.Dispose();
		}
		super.Dispose(disposing);
	}

//C# TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
		///#region Windows Form Designer generated code

	/** 
	 Required method for Designer support - do not modify
	 the contents of this method with the code editor.
	*/
	private void InitializeComponent()
	{
		this.button1 = new System.Windows.Forms.Button();
		this.pictureBox1 = new System.Windows.Forms.PictureBox();
		this.richTextBox1 = new System.Windows.Forms.RichTextBox();
		((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
		this.SuspendLayout();
		// 
		// button1
		// 
		this.button1.Location = new System.Drawing.Point(187, 239);
		this.button1.Name = "button1";
		this.button1.Size = new System.Drawing.Size(75, 23);
		this.button1.TabIndex = 0;
		this.button1.Text = "Back";
		this.button1.UseVisualStyleBackColor = true;
//C# TO JAVA CONVERTER TODO TASK: Java has no equivalent to C#-style event wireups:
		this.button1.Click += new System.EventHandler(this.button1_Click);
		// 
		// pictureBox1
		// 
		this.pictureBox1.Location = new System.Drawing.Point(41, 37);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new System.Drawing.Size(81, 88);
		this.pictureBox1.TabIndex = 1;
		this.pictureBox1.TabStop = false;
		// 
		// richTextBox1
		// 
		this.richTextBox1.Location = new System.Drawing.Point(41, 132);
		this.richTextBox1.Name = "richTextBox1";
		this.richTextBox1.Size = new System.Drawing.Size(100, 130);
		this.richTextBox1.TabIndex = 2;
		this.richTextBox1.Text = "";
		// 
		// Endomorphs
		// 
		this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.ClientSize = new System.Drawing.Size(284, 261);
		this.Controls.Add(this.richTextBox1);
		this.Controls.Add(this.pictureBox1);
		this.Controls.Add(this.button1);
		this.Name = "Endomorphs";
		this.Text = "Endomorphs";
//C# TO JAVA CONVERTER TODO TASK: Java has no equivalent to C#-style event wireups:
		this.Load += new System.EventHandler(this.Endomorphs_Load);
		((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
		this.ResumeLayout(false);

	}

//C# TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
		///#endregion

	private System.Windows.Forms.Button button1;
	private System.Windows.Forms.PictureBox pictureBox1;
	private System.Windows.Forms.RichTextBox richTextBox1;
}