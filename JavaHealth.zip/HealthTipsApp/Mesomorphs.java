package HealthTipsApp;

public class Mesomorphs extends Form
{
	public Mesomorphs()
	{
		InitializeComponent();
	}

	private void button1_Click(Object sender, tangible.EventArgs e)
	{
		Form1 main = new Form1();
		main.Show();
		this.Hide();
	}

	private void Mesomorphs_Load(Object sender, tangible.EventArgs e)
	{
		pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
		pictureBox1.ImageLocation = "http://ironflex.com.ua/i/Events/vse-kozyri-v-vashih-rukah-posvjashaetsja-mezoformam-1168.jpeg";
		richTextBox1.Text = "The guy that gains muscle when he walks into the weight room.\nPerfect mesomorphs are those guys who are naturally good at everything, without even putting in the practice. \nThey have an athletic physique, a strong bone structure and have a better innate ability to pack on muscle very well, while also being able to gain more fat than ectomorphs and less than endomorphs.These guys don’t really have to accept anything – they’re genetically blessed.\nThere’s one thing a mesomorph needs to accept, it’s that they need to make sure they maintain that balance between strength and interval/cardio training.";
	}


	/** 
	 Required designer variable.
	*/
	private System.ComponentModel.IContainer components = null;

	/** 
	 Clean up any resources being used.
	 
	 @param disposing true if managed resources should be disposed; otherwise, false.
	*/
	@Override
	protected void Dispose(boolean disposing)
	{
		if (disposing && (components != null))
		{
			components.Dispose();
		}
		super.Dispose(disposing);
	}

//C# TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
		///#region Windows Form Designer generated code

	/** 
	 Required method for Designer support - do not modify
	 the contents of this method with the code editor.
	*/
	private void InitializeComponent()
	{
		this.button1 = new System.Windows.Forms.Button();
		this.pictureBox1 = new System.Windows.Forms.PictureBox();
		this.richTextBox1 = new System.Windows.Forms.RichTextBox();
		((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
		this.SuspendLayout();
		// 
		// button1
		// 
		this.button1.Location = new System.Drawing.Point(166, 251);
		this.button1.Name = "button1";
		this.button1.Size = new System.Drawing.Size(75, 23);
		this.button1.TabIndex = 0;
		this.button1.Text = "Back";
		this.button1.UseVisualStyleBackColor = true;
//C# TO JAVA CONVERTER TODO TASK: Java has no equivalent to C#-style event wireups:
		this.button1.Click += new System.EventHandler(this.button1_Click);
		// 
		// pictureBox1
		// 
		this.pictureBox1.Location = new System.Drawing.Point(43, 12);
		this.pictureBox1.Name = "pictureBox1";
		this.pictureBox1.Size = new System.Drawing.Size(80, 88);
		this.pictureBox1.TabIndex = 1;
		this.pictureBox1.TabStop = false;
		// 
		// richTextBox1
		// 
		this.richTextBox1.Location = new System.Drawing.Point(22, 119);
		this.richTextBox1.Name = "richTextBox1";
		this.richTextBox1.Size = new System.Drawing.Size(138, 155);
		this.richTextBox1.TabIndex = 2;
		this.richTextBox1.Text = "";
		// 
		// Mesomorphs
		// 
		this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
		this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
		this.ClientSize = new System.Drawing.Size(249, 298);
		this.Controls.Add(this.richTextBox1);
		this.Controls.Add(this.pictureBox1);
		this.Controls.Add(this.button1);
		this.Name = "Mesomorphs";
		this.Text = "Mezomorphs";
//C# TO JAVA CONVERTER TODO TASK: Java has no equivalent to C#-style event wireups:
		this.Load += new System.EventHandler(this.Mesomorphs_Load);
		((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
		this.ResumeLayout(false);

	}

//C# TO JAVA CONVERTER TODO TASK: There is no preprocessor in Java:
		///#endregion

	private System.Windows.Forms.Button button1;
	private System.Windows.Forms.PictureBox pictureBox1;
	private System.Windows.Forms.RichTextBox richTextBox1;
}